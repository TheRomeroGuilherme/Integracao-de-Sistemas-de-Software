import { criarProduto } from './produtoService.js';

describe('produtoService', () => {
    it('deve lançar erro quando o nome for apenas espaços', () => {
      expect(() => criarProduto({ nome: '   ', preco: 100 })).toThrow(
        'O nome do produto não pode ser vazio.'
      );
    });
});
