const produtos = [
  { id: 1, nome: 'Notebook', preco: 3500.00 },
  { id: 2, nome: 'Mouse', preco: 150.00 },
  { id: 3, nome: 'Teclado', preco: 250.00 },
];

let nextId = 4;

export function listarProdutos() {
  return produtos;
}


export function criarProduto({ nome, preco }) {
  if (!nome || nome.trim() === '') {
    throw new Error('O nome do produto não pode ser vazio.');
  }
  if (preco == null || isNaN(preco) || preco < 0) {
    throw new Error('O preço do produto é inválido.');
  }

  const novoProduto = { id: nextId++, nome: nome.trim(), preco: Number(preco) };
  produtos.push(novoProduto);
  return novoProduto;
}
