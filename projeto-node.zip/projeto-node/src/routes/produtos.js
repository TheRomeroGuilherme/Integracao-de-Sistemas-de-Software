import { Router } from 'express';
import {
  listarProdutos,
  criarProduto,
} from '../services/produtoService.js';

const router = Router();

router.get('/', (req, res) => {
  const produtos = listarProdutos();
  res.json(produtos);
});

router.post('/', (req, res) => {
  try {
    const produto = criarProduto(req.body);
    res.status(201).json(produto);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

export default router;
