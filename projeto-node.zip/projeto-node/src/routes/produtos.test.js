// Exercício 02: Teste de integração com Supertest para GET /produtos

import request from 'supertest';
import app from '../app.js';

describe('GET /produtos', () => {
  it('deve retornar status 200 e uma lista de produtos', async () => {
    const res = await request(app).get('/produtos');

    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('cada produto deve ter id, nome e preco', async () => {
    const res = await request(app).get('/produtos');

    res.body.forEach((produto) => {
      expect(produto).toHaveProperty('id');
      expect(produto).toHaveProperty('nome');
      expect(produto).toHaveProperty('preco');
    });
  });

  it('deve retornar Content-Type application/json', async () => {
    const res = await request(app).get('/produtos');
    expect(res.headers['content-type']).toMatch(/application\/json/);
  });
});

describe('POST /produtos', () => {
  it('deve criar um produto válido e retornar 201', async () => {
    const res = await request(app)
      .post('/produtos')
      .send({ nome: 'Headset', preco: 450 });

    expect(res.status).toBe(201);
    expect(res.body.nome).toBe('Headset');
    expect(res.body.preco).toBe(450);
  });

  it('deve retornar 400 ao criar produto com nome vazio', async () => {
    const res = await request(app)
      .post('/produtos')
      .send({ nome: '', preco: 100 });

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty('erro');
  });
});
