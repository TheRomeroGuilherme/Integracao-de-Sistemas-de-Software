import express from 'express';
import morgan from 'morgan';
import produtosRouter from './routes/produtos.js';

const app = express();

app.use(morgan('dev'));

app.use(express.json());

app.use('/produtos', produtosRouter);

app.get('/', (req, res) => {
  res.json({ mensagem: 'API de Produtos' });
});

export default app;
