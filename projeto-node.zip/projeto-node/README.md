# Produto API — Express 5 + ESModules

API REST de produtos com testes unitários (Jest), testes de integração (Supertest) e logging (Morgan).

## Instalação

```bash
npm install
```

## Rodar Projeto
```bash
npm run start
```

## Testes

```bash
npm test
```
